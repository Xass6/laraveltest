<?php

use Illuminate\Database\Seeder;

class ReservationsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('reservations')->insert([
          [
              "name" => "Disponible",
          ],
          [
              "name" => "Réservé",
          ]
        ]);
    }
}
