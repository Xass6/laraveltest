<?php

use Illuminate\Database\Seeder;

class SallesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('salles')->insert([
          [
              "name" => "Halle Tony Garnier",
              "lieux" => "Lyon",
              "places" => "500",
              "reservation_id" => "1"
          ],
          [
              "name" => "AccorHotels Arena",
              "lieux" => "Paris",
              "places" => "1000",
              "reservation_id" => "1"
          ],
          [
              "name" => "Transbordeur",
              "lieux" => "Villeurbanne",
              "places" => "200",
              "reservation_id" => "2"
          ]
        ]);
    }
}
