<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Reservation as Reservation;
use App\Salle as Salle;

class View extends Controller
{
  public function showSalle()
  {
    $salles = Salle::all();
    return view ('home', [
      'salles' => $salles
    ]);
  }
  public function addSalles()
  {
      $salles = Salle::all();
      $reservations = Reservation::all();
      return view('addSalles', [
      "salles" => $salles,
      "reservation" => $reservations,
      ]);
   }
   public function insertOne(Request $request)
    {
      $salle = new Salle;
      $salle->name = $request->input('name');
      $salle->lieux = $request->input('lieux');
      $salle->places = $request->input('places');
      $salle->reservation_id = $request->input('reservation');
      $salle->save();
      return redirect('/');
    }
    public function updateForm(Request $request)
        {
        $salles = Salle::find($request->input('id'));
        $reservations = Reservation::all();
        return view('update',[
            'salles'=>$salles,
            'reservations'=>$reservations,
        ]);
    }

    public function updateOne(Request $request)
    {
      $salles = Salle::find($request->input('id'));
      $salles->reservation_id = $request->input('reservation');
      $salles->save();
      return redirect('/');

    }
    public function deleteOne(Request $request)
    {
      $salles= Salle::find($request->id);
      $salles->delete();
      return redirect('/');
    }
}
