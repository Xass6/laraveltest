<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'View@showSalle');
Route::get('/addSalles', 'View@addSalles');

Route::post('/updatesalle', 'View@updateForm');
Route::post('/updatesalleaction', 'View@updateOne');
Route::post('/insertsalle', 'View@insertOne');
Route::post('/deletesalle', 'View@deleteOne');
