@extends('templates.header')

@section('title', 'Modifier une salle')

@section('content')
        <div> {{ $salles->name }} </div>
        <div> {{ $salles->lieux }} </div>
        <div> {{ $salles->places }} </div>
        <form class="" action="/updatesalleaction" method="post">
          @csrf
          <input type="hidden" name="id" value="{{ $salles->id }}" >
          <select multiple name="reservation">
              @foreach ($reservations as $reserv)
                <option value="{{$reserv->id}}"
                  {{-- @foreach ($salles->reservation as $reservs)
                    @if($reservs->id == $reserv->id)
                        selected
                    @endif
                  @endforeach --}}
                          >{{ $reserv->name }}
                      </option>
              @endforeach
          </select>
          <input type="submit" name="" value="Insert">
        </form>
@endsection
