@extends('templates.header')

@section('title', 'Toute les salles de concerts')

@section('content')
  <p>Liste des salles :</p>
  <table>
  <tr>
      <th>Nom</th>
      <th>Lieux</th>
      <th>Capacités</th>
      <th>Disponibilité</th>
  </tr>
      @foreach($salles as $salle)
          <tr>
          <td>{{ $salle->name }}</td>
          <td>{{ $salle->lieux }}</td>
          <td>{{ $salle->places }}</td>
          <td>{{ $salle->reservation->name }}</td>
            {{-- @foreach ($salle->reservations as $reservation)
                {{ $reservation->name }}</br>
            @endforeach --}}
          {{-- </td> --}}
          <td>
            <form class="" action="/deletesalle" method="post">
              @csrf
              <input type="hidden" name="id" value="{{ $salle->id }}">
              <input type="submit" name="" value="X">
            </form>
        </td>
        <td>
            <form class="" action="/updatesalle" method="post">
              @csrf
              <input type="hidden" name="id" value="{{ $salle->id }}">
              <input type="submit" name="" value="update">
            </form>
        </td>
      </tr>
      @endforeach
  </table>
@endsection
