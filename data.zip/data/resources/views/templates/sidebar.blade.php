<ul>
  <li><a class="menu" href="./">Home</a></li>
  <li><a class="menu" href="./addSalles">Ajouter une salle</a></li>
</ul>
