@extends('templates.header')

@section('title', 'Ajouter une salles de concerts')

@section('content')
  <form class="" action="/insertsalle" method="post">
    @csrf
        <input placeholder="Nom de la salle" type="text" name="name" value="" required>
        <input placeholder="Lyon" type="text" name="lieux" value="">
        <input placeholder="Places dans la salle" type="text" name="places" value="">
        <select multiple name="reservation">
            @foreach ($reservation as $reserv)
                <option value="{{ $reserv->id }}">
                    {{ $reserv->name }}
                </option>
            @endforeach
        </select>
    <input type="submit" name="" value="Insert">
  </form>
@endsection
