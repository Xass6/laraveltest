<html>
    <head>
        <title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
        <link rel="stylesheet"  href="<?php echo e(asset('./css/style.css')); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css?family=Monoton" rel="stylesheet">
    </head>
    <body>
      <header>
          <?php echo $__env->make('./templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </header>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </body>
    <script type="text/javascript" src="<?php echo e(asset('./js/script.js')); ?>"></script>
</html>
