<?php $__env->startSection('title', 'Toute les salles de concerts'); ?>

<?php $__env->startSection('content'); ?>
  <p>Liste des salles :</p>
  <table>
  <tr>
      <th>Nom</th>
      <th>Lieux</th>
      <th>Capacités</th>
      <th>Disponibilité</th>
  </tr>
      <?php $__currentLoopData = $salles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
          <td><?php echo e($salle->name); ?></td>
          <td><?php echo e($salle->lieux); ?></td>
          <td><?php echo e($salle->places); ?></td>
          <td><?php echo e($salle->reservation->name); ?></td>
            
          
          <td>
            <form class="" action="/deletesalle" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="id" value="<?php echo e($salle->id); ?>">
              <input type="submit" name="" value="X">
            </form>
        </td>
        <td>
            <form class="" action="/updatesalle" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="id" value="<?php echo e($salle->id); ?>">
              <input type="submit" name="" value="update">
            </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>