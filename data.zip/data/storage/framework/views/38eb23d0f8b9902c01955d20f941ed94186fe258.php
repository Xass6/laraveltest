<?php $__env->startSection('title', 'Modifier une salle'); ?>

<?php $__env->startSection('content'); ?>
        <div> <?php echo e($salles->name); ?> </div>
        <div> <?php echo e($salles->lieux); ?> </div>
        <div> <?php echo e($salles->places); ?> </div>
        <form class="" action="/updatesalleaction" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="id" value="<?php echo e($salles->id); ?>" >
          <select multiple name="reservation">
              <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($reserv->id); ?>"
                  
                          ><?php echo e($reserv->name); ?>

                      </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <input type="submit" name="" value="Insert">
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>