<?php $__env->startSection('title', 'Ajouter une salles de concerts'); ?>

<?php $__env->startSection('content'); ?>
  <form class="" action="/insertsalle" method="post">
    <?php echo csrf_field(); ?>
        <input placeholder="Nom de la salle" type="text" name="name" value="" required>
        <input placeholder="Lyon" type="text" name="lieux" value="">
        <input placeholder="Places dans la salle" type="text" name="places" value="">
        <select multiple name="reservation">
            <?php $__currentLoopData = $reservation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($reserv->id); ?>">
                    <?php echo e($reserv->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <input type="submit" name="" value="Insert">
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>